
import 'package:flutter/material.dart';
import 'lessons_screen.dart';

class LessonDetailScreen extends StatelessWidget {
  final Lesson lesson;

  LessonDetailScreen({required this.lesson});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(lesson.title)),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(lesson.content, style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ...List.generate(lesson.options.length, (i) {
              return ElevatedButton(
                onPressed: () {
                  final correct = (i == lesson.correctAnswerIndex);
                  final msg = correct ? "إجابة صحيحة!" : "حاول مرة أخرى.";
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
                },
                child: Text(lesson.options[i]),
              );
            }),
          ],
        ),
      ),
    );
  }
}
