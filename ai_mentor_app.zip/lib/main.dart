
import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'lessons_screen.dart';

void main() {
  runApp(AIMentorApp());
}

class AIMentorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LessonsScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
