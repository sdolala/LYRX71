
import 'package:flutter/material.dart';
import 'lesson_detail_screen.dart';

class Lesson {
  final String title;
  final String content;
  final List<String> options;
  final int correctAnswerIndex;

  Lesson(this.title, this.content, this.options, this.correctAnswerIndex);
}

final lessons = [
  Lesson(
    "مقدمة في الذكاء الاصطناعي",
    "الذكاء الاصطناعي هو قدرة الآلات على تقليد الذكاء البشري...",
    ["برنامج يتصرف بذكاء بشري", "لعبة فيديو", "موقع تواصل اجتماعي"],
    0,
  ),
  Lesson(
    "تعلم الآلة",
    "تعلم الآلة هو طريقة تعليم الآلات بدون برمجة مباشرة...",
    ["تعلم من بيانات معنونة", "تعلم بدون بيانات", "تعلم عميق"],
    0,
  ),
];

class LessonsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("AI Mentor")),
      body: ListView.builder(
        itemCount: lessons.length,
        itemBuilder: (context, index) {
          final lesson = lessons[index];
          return ListTile(
            title: Text(lesson.title),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => LessonDetailScreen(lesson: lesson),
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.chat),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ChatScreen()),
          );
        },
      ),
    );
  }
}
